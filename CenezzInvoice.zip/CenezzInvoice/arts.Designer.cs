﻿namespace CenezzInvoice
{
    partial class arts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(arts));
            this.lister = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lineas = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.cves = new System.Windows.Forms.TextBox();
            this.skus = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.idinvo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cvee = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.sizele = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.pallete = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.mede = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.kgcajae = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.m2cajae = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.kgpze = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cajae = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.unide = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.costoe = new System.Windows.Forms.TextBox();
            this.linee = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.precioe = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.skue = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.descre = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label39 = new System.Windows.Forms.Label();
            this.sizel = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.pallet = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.med = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.descr = new System.Windows.Forms.TextBox();
            this.kgcaja = new System.Windows.Forms.TextBox();
            this.cve = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.m2caja = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.sku = new System.Windows.Forms.TextBox();
            this.kgpz = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.precio = new System.Windows.Forms.TextBox();
            this.caja = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.line = new System.Windows.Forms.ComboBox();
            this.unid = new System.Windows.Forms.ComboBox();
            this.costo = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.descrpnval = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.nvalistn = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.desclist = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.pcolist = new System.Windows.Forms.TextBox();
            this.listap = new System.Windows.Forms.ComboBox();
            this.lineadel = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.lincuan = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.lister)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lister
            // 
            this.lister.AllowUserToAddRows = false;
            this.lister.AllowUserToDeleteRows = false;
            this.lister.AllowUserToResizeRows = false;
            this.lister.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.lister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lister.Location = new System.Drawing.Point(25, 163);
            this.lister.MultiSelect = false;
            this.lister.Name = "lister";
            this.lister.ReadOnly = true;
            this.lister.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.lister.RowHeadersVisible = false;
            this.lister.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.lister.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.lister.Size = new System.Drawing.Size(809, 109);
            this.lister.TabIndex = 1;
            this.lister.TabStop = false;
            this.lister.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.lister_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lineas);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.cves);
            this.groupBox1.Controls.Add(this.skus);
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(26, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(442, 115);
            this.groupBox1.TabIndex = 261;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Herramientas";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 266;
            this.label1.Text = "Linea: ";
            // 
            // lineas
            // 
            this.lineas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lineas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineas.FormattingEnabled = true;
            this.lineas.Location = new System.Drawing.Point(75, 73);
            this.lineas.Name = "lineas";
            this.lineas.Size = new System.Drawing.Size(142, 26);
            this.lineas.TabIndex = 265;
            this.lineas.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 259;
            this.label5.Text = "# SKU:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 258;
            this.label4.Text = "Clave:";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(361, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 67);
            this.button2.TabIndex = 264;
            this.button2.Text = "Eliminar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cves
            // 
            this.cves.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cves.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cves.Location = new System.Drawing.Point(75, 29);
            this.cves.Name = "cves";
            this.cves.Size = new System.Drawing.Size(142, 20);
            this.cves.TabIndex = 257;
            this.cves.TabStop = false;
            // 
            // skus
            // 
            this.skus.Location = new System.Drawing.Point(75, 51);
            this.skus.Name = "skus";
            this.skus.Size = new System.Drawing.Size(142, 20);
            this.skus.TabIndex = 256;
            this.skus.TabStop = false;
            // 
            // button9
            // 
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.Location = new System.Drawing.Point(289, 31);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(66, 67);
            this.button9.TabIndex = 263;
            this.button9.Text = "Excel";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Image = global::CenezzInvoice.Properties.Resources.mail_find;
            this.button1.Location = new System.Drawing.Point(223, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 71);
            this.button1.TabIndex = 1;
            this.button1.Text = "Buscar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // idinvo
            // 
            this.idinvo.Location = new System.Drawing.Point(671, 16);
            this.idinvo.Name = "idinvo";
            this.idinvo.Size = new System.Drawing.Size(25, 20);
            this.idinvo.TabIndex = 265;
            this.idinvo.TabStop = false;
            this.idinvo.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(347, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 23);
            this.label3.TabIndex = 266;
            this.label3.Text = "Articulos activos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 268;
            this.label2.Text = "Clave:";
            // 
            // cvee
            // 
            this.cvee.Location = new System.Drawing.Point(53, 19);
            this.cvee.Name = "cvee";
            this.cvee.ReadOnly = true;
            this.cvee.Size = new System.Drawing.Size(106, 20);
            this.cvee.TabIndex = 267;
            this.cvee.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.sizele);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.pallete);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.mede);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.kgcajae);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.m2cajae);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.kgpze);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.cajae);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.unide);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.costoe);
            this.groupBox2.Controls.Add(this.linee);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.precioe);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.skue);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.descre);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cvee);
            this.groupBox2.Location = new System.Drawing.Point(26, 275);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(396, 212);
            this.groupBox2.TabIndex = 269;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Editar";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(341, 103);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(45, 13);
            this.label38.TabIndex = 319;
            this.label38.Text = "en Cms.";
            this.label38.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // sizele
            // 
            this.sizele.Location = new System.Drawing.Point(286, 99);
            this.sizele.Name = "sizele";
            this.sizele.Size = new System.Drawing.Size(52, 20);
            this.sizele.TabIndex = 318;
            this.sizele.TabStop = false;
            this.sizele.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sizele_KeyPress);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(270, 103);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(14, 13);
            this.label36.TabIndex = 317;
            this.label36.Text = "X";
            this.label36.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(75, 182);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(89, 13);
            this.label34.TabIndex = 316;
            this.label34.Text = "Unidades x Pallet";
            // 
            // pallete
            // 
            this.pallete.Location = new System.Drawing.Point(167, 178);
            this.pallete.Name = "pallete";
            this.pallete.Size = new System.Drawing.Size(102, 20);
            this.pallete.TabIndex = 315;
            this.pallete.TabStop = false;
            this.pallete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pallete_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(161, 103);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(50, 13);
            this.label27.TabIndex = 314;
            this.label27.Text = "Medidas:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // mede
            // 
            this.mede.Location = new System.Drawing.Point(213, 99);
            this.mede.Name = "mede";
            this.mede.Size = new System.Drawing.Size(56, 20);
            this.mede.TabIndex = 313;
            this.mede.TabStop = false;
            this.mede.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mede_KeyPress);
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(278, 124);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(97, 73);
            this.button5.TabIndex = 312;
            this.button5.Text = "Guardar Cambios";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(164, 156);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 13);
            this.label14.TabIndex = 288;
            this.label14.Text = "Kg Caja:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // kgcajae
            // 
            this.kgcajae.Location = new System.Drawing.Point(213, 152);
            this.kgcajae.Name = "kgcajae";
            this.kgcajae.Size = new System.Drawing.Size(56, 20);
            this.kgcajae.TabIndex = 287;
            this.kgcajae.TabStop = false;
            this.kgcajae.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kgcajae_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(166, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 286;
            this.label15.Text = "m² Caja:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // m2cajae
            // 
            this.m2cajae.Location = new System.Drawing.Point(213, 126);
            this.m2cajae.Name = "m2cajae";
            this.m2cajae.Size = new System.Drawing.Size(56, 20);
            this.m2cajae.TabIndex = 285;
            this.m2cajae.TabStop = false;
            this.m2cajae.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.m2cajae_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 156);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 13);
            this.label16.TabIndex = 284;
            this.label16.Text = "Kg Pz:";
            // 
            // kgpze
            // 
            this.kgpze.Location = new System.Drawing.Point(54, 153);
            this.kgpze.Name = "kgpze";
            this.kgpze.Size = new System.Drawing.Size(106, 20);
            this.kgpze.TabIndex = 283;
            this.kgpze.TabStop = false;
            this.kgpze.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kgpze_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 130);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 13);
            this.label17.TabIndex = 282;
            this.label17.Text = "Pzas Caja:";
            // 
            // cajae
            // 
            this.cajae.Location = new System.Drawing.Point(69, 126);
            this.cajae.Name = "cajae";
            this.cajae.Size = new System.Drawing.Size(91, 20);
            this.cajae.TabIndex = 281;
            this.cajae.TabStop = false;
            this.cajae.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cajae_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 280;
            this.label13.Text = "Unidad:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // unide
            // 
            this.unide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unide.FormattingEnabled = true;
            this.unide.Location = new System.Drawing.Point(53, 98);
            this.unide.Name = "unide";
            this.unide.Size = new System.Drawing.Size(106, 23);
            this.unide.TabIndex = 279;
            this.unide.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 268;
            this.label12.Text = "Linea: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(173, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 278;
            this.label11.Text = "Costo:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // costoe
            // 
            this.costoe.Location = new System.Drawing.Point(212, 71);
            this.costoe.Name = "costoe";
            this.costoe.Size = new System.Drawing.Size(106, 20);
            this.costoe.TabIndex = 277;
            this.costoe.TabStop = false;
            this.costoe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.costoe_KeyPress);
            // 
            // linee
            // 
            this.linee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linee.FormattingEnabled = true;
            this.linee.Location = new System.Drawing.Point(53, 70);
            this.linee.Name = "linee";
            this.linee.Size = new System.Drawing.Size(106, 23);
            this.linee.TabIndex = 267;
            this.linee.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(170, 49);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 276;
            this.label10.Text = "Precio:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // precioe
            // 
            this.precioe.Location = new System.Drawing.Point(212, 45);
            this.precioe.Name = "precioe";
            this.precioe.Size = new System.Drawing.Size(106, 20);
            this.precioe.TabIndex = 275;
            this.precioe.TabStop = false;
            this.precioe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.precioe_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(178, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 274;
            this.label9.Text = "SKU:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // skue
            // 
            this.skue.Location = new System.Drawing.Point(212, 19);
            this.skue.Name = "skue";
            this.skue.Size = new System.Drawing.Size(106, 20);
            this.skue.TabIndex = 273;
            this.skue.TabStop = false;
            this.skue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.skue_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 270;
            this.label7.Text = "Descr:";
            // 
            // descre
            // 
            this.descre.Location = new System.Drawing.Point(53, 45);
            this.descre.Name = "descre";
            this.descre.Size = new System.Drawing.Size(106, 20);
            this.descre.TabIndex = 269;
            this.descre.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.sizel);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.pallet);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.med);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.descr);
            this.groupBox3.Controls.Add(this.kgcaja);
            this.groupBox3.Controls.Add(this.cve);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.m2caja);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.sku);
            this.groupBox3.Controls.Add(this.kgpz);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.precio);
            this.groupBox3.Controls.Add(this.caja);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.line);
            this.groupBox3.Controls.Add(this.unid);
            this.groupBox3.Controls.Add(this.costo);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Location = new System.Drawing.Point(427, 275);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(407, 212);
            this.groupBox3.TabIndex = 270;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Nuevo";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(357, 107);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(45, 13);
            this.label39.TabIndex = 320;
            this.label39.Text = "en Cms.";
            this.label39.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // sizel
            // 
            this.sizel.Location = new System.Drawing.Point(303, 103);
            this.sizel.Name = "sizel";
            this.sizel.Size = new System.Drawing.Size(52, 20);
            this.sizel.TabIndex = 320;
            this.sizel.TabStop = false;
            this.sizel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sizel_KeyPress);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(288, 107);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(14, 13);
            this.label37.TabIndex = 319;
            this.label37.Text = "X";
            this.label37.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(93, 190);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(89, 13);
            this.label35.TabIndex = 318;
            this.label35.Text = "Unidades x Pallet";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(178, 107);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(50, 13);
            this.label28.TabIndex = 316;
            this.label28.Text = "Medidas:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // pallet
            // 
            this.pallet.Location = new System.Drawing.Point(185, 186);
            this.pallet.Name = "pallet";
            this.pallet.Size = new System.Drawing.Size(102, 20);
            this.pallet.TabIndex = 317;
            this.pallet.TabStop = false;
            this.pallet.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pallet_KeyPress);
            // 
            // button4
            // 
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(293, 129);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 77);
            this.button4.TabIndex = 313;
            this.button4.Text = "Guardar Articulo";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // med
            // 
            this.med.Location = new System.Drawing.Point(229, 103);
            this.med.Name = "med";
            this.med.Size = new System.Drawing.Size(57, 20);
            this.med.TabIndex = 315;
            this.med.TabStop = false;
            this.med.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.med_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(178, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 310;
            this.label6.Text = "Kg Caja:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // descr
            // 
            this.descr.Location = new System.Drawing.Point(67, 49);
            this.descr.Name = "descr";
            this.descr.Size = new System.Drawing.Size(106, 20);
            this.descr.TabIndex = 293;
            this.descr.TabStop = false;
            // 
            // kgcaja
            // 
            this.kgcaja.Location = new System.Drawing.Point(229, 162);
            this.kgcaja.Name = "kgcaja";
            this.kgcaja.Size = new System.Drawing.Size(57, 20);
            this.kgcaja.TabIndex = 309;
            this.kgcaja.TabStop = false;
            this.kgcaja.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kgcaja_KeyPress);
            // 
            // cve
            // 
            this.cve.Location = new System.Drawing.Point(67, 23);
            this.cve.Name = "cve";
            this.cve.Size = new System.Drawing.Size(106, 20);
            this.cve.TabIndex = 289;
            this.cve.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(180, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 308;
            this.label8.Text = "m² Caja:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(27, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 13);
            this.label26.TabIndex = 291;
            this.label26.Text = "Clave:";
            // 
            // m2caja
            // 
            this.m2caja.Location = new System.Drawing.Point(229, 136);
            this.m2caja.Name = "m2caja";
            this.m2caja.Size = new System.Drawing.Size(57, 20);
            this.m2caja.TabIndex = 307;
            this.m2caja.TabStop = false;
            this.m2caja.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.m2caja_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(26, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 13);
            this.label25.TabIndex = 294;
            this.label25.Text = "Descr:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(26, 166);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(38, 13);
            this.label18.TabIndex = 306;
            this.label18.Text = "Kg Pz:";
            // 
            // sku
            // 
            this.sku.Location = new System.Drawing.Point(229, 23);
            this.sku.Name = "sku";
            this.sku.Size = new System.Drawing.Size(106, 20);
            this.sku.TabIndex = 295;
            this.sku.TabStop = false;
            this.sku.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sku_KeyPress);
            // 
            // kgpz
            // 
            this.kgpz.Location = new System.Drawing.Point(67, 163);
            this.kgpz.Name = "kgpz";
            this.kgpz.Size = new System.Drawing.Size(106, 20);
            this.kgpz.TabIndex = 305;
            this.kgpz.TabStop = false;
            this.kgpz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kgpz_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(193, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 296;
            this.label24.Text = "SKU:";
            this.label24.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 140);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 13);
            this.label19.TabIndex = 304;
            this.label19.Text = "Pzas Caja:";
            // 
            // precio
            // 
            this.precio.Location = new System.Drawing.Point(229, 49);
            this.precio.Name = "precio";
            this.precio.Size = new System.Drawing.Size(106, 20);
            this.precio.TabIndex = 297;
            this.precio.TabStop = false;
            this.precio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.precio_KeyPress);
            // 
            // caja
            // 
            this.caja.Location = new System.Drawing.Point(67, 136);
            this.caja.Name = "caja";
            this.caja.Size = new System.Drawing.Size(106, 20);
            this.caja.TabIndex = 303;
            this.caja.TabStop = false;
            this.caja.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.caja_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(185, 53);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 13);
            this.label23.TabIndex = 298;
            this.label23.Text = "Precio:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 108);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 13);
            this.label20.TabIndex = 302;
            this.label20.Text = "Unidad:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // line
            // 
            this.line.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.line.FormattingEnabled = true;
            this.line.Location = new System.Drawing.Point(67, 74);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(106, 23);
            this.line.TabIndex = 290;
            this.line.TabStop = false;
            // 
            // unid
            // 
            this.unid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unid.FormattingEnabled = true;
            this.unid.Location = new System.Drawing.Point(67, 102);
            this.unid.Name = "unid";
            this.unid.Size = new System.Drawing.Size(106, 23);
            this.unid.TabIndex = 301;
            this.unid.TabStop = false;
            // 
            // costo
            // 
            this.costo.Location = new System.Drawing.Point(229, 75);
            this.costo.Name = "costo";
            this.costo.Size = new System.Drawing.Size(106, 20);
            this.costo.TabIndex = 299;
            this.costo.TabStop = false;
            this.costo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.costo_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(25, 80);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(39, 13);
            this.label21.TabIndex = 292;
            this.label21.Text = "Linea: ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(188, 79);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 300;
            this.label22.Text = "Costo:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(702, 16);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(132, 23);
            this.button3.TabIndex = 311;
            this.button3.Text = "Salir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.descrpnval);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.nvalistn);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.desclist);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.pcolist);
            this.groupBox4.Controls.Add(this.listap);
            this.groupBox4.Location = new System.Drawing.Point(473, 42);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(361, 115);
            this.groupBox4.TabIndex = 312;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Precios del producto";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(326, 56);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(22, 23);
            this.button8.TabIndex = 324;
            this.button8.Text = "-";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Green;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(326, 87);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(22, 23);
            this.button7.TabIndex = 323;
            this.button7.Text = "+";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // descrpnval
            // 
            this.descrpnval.Location = new System.Drawing.Point(207, 88);
            this.descrpnval.Name = "descrpnval";
            this.descrpnval.Size = new System.Drawing.Size(113, 20);
            this.descrpnval.TabIndex = 321;
            this.descrpnval.TabStop = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(159, 92);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(46, 13);
            this.label33.TabIndex = 322;
            this.label33.Text = "Descrip:";
            this.label33.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(5, 92);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(42, 13);
            this.label32.TabIndex = 320;
            this.label32.Text = "Nueva:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // nvalistn
            // 
            this.nvalistn.Location = new System.Drawing.Point(50, 88);
            this.nvalistn.Name = "nvalistn";
            this.nvalistn.Size = new System.Drawing.Size(106, 20);
            this.nvalistn.TabIndex = 319;
            this.nvalistn.TabStop = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(162, 56);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(158, 23);
            this.button6.TabIndex = 313;
            this.button6.Text = "Actualizar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // desclist
            // 
            this.desclist.Location = new System.Drawing.Point(162, 34);
            this.desclist.Name = "desclist";
            this.desclist.Size = new System.Drawing.Size(186, 20);
            this.desclist.TabIndex = 317;
            this.desclist.TabStop = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(165, 18);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 13);
            this.label31.TabIndex = 318;
            this.label31.Text = "Descripción:";
            this.label31.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(8, 62);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 13);
            this.label30.TabIndex = 316;
            this.label30.Text = "Precio:";
            this.label30.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(84, 13);
            this.label29.TabIndex = 270;
            this.label29.Text = "Lista de precios:";
            // 
            // pcolist
            // 
            this.pcolist.Location = new System.Drawing.Point(50, 58);
            this.pcolist.Name = "pcolist";
            this.pcolist.Size = new System.Drawing.Size(106, 20);
            this.pcolist.TabIndex = 315;
            this.pcolist.TabStop = false;
            this.pcolist.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.pcolist_KeyPress);
            // 
            // listap
            // 
            this.listap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listap.FormattingEnabled = true;
            this.listap.Location = new System.Drawing.Point(6, 32);
            this.listap.Name = "listap";
            this.listap.Size = new System.Drawing.Size(150, 23);
            this.listap.TabIndex = 269;
            this.listap.TabStop = false;
            this.listap.SelectedIndexChanged += new System.EventHandler(this.listap_SelectedIndexChanged);
            // 
            // lineadel
            // 
            this.lineadel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lineadel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineadel.FormattingEnabled = true;
            this.lineadel.Location = new System.Drawing.Point(840, 73);
            this.lineadel.Name = "lineadel";
            this.lineadel.Size = new System.Drawing.Size(106, 23);
            this.lineadel.TabIndex = 313;
            this.lineadel.TabStop = false;
            this.lineadel.SelectedIndexChanged += new System.EventHandler(this.lineadel_SelectedIndexChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(838, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(84, 13);
            this.label40.TabIndex = 314;
            this.label40.Text = "Lineas actuales:";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(839, 97);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(106, 23);
            this.button10.TabIndex = 325;
            this.button10.Text = "Eliminar Linea";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // lincuan
            // 
            this.lincuan.AutoSize = true;
            this.lincuan.Location = new System.Drawing.Point(843, 123);
            this.lincuan.Name = "lincuan";
            this.lincuan.Size = new System.Drawing.Size(0, 13);
            this.lincuan.TabIndex = 326;
            // 
            // arts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 580);
            this.Controls.Add(this.lincuan);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.lineadel);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idinvo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lister);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "arts";
            this.Text = "Catalogo de Articulos";
            this.Deactivate += new System.EventHandler(this.arts_Deactivate);
            this.Load += new System.EventHandler(this.arts_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.arts_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.lister)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView lister;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox cves;
        private System.Windows.Forms.TextBox skus;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox idinvo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox lineas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox cvee;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox kgcajae;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox m2cajae;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox kgpze;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox cajae;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox unide;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox costoe;
        private System.Windows.Forms.ComboBox linee;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox precioe;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox skue;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox descre;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox descr;
        private System.Windows.Forms.TextBox kgcaja;
        private System.Windows.Forms.TextBox cve;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox m2caja;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox sku;
        private System.Windows.Forms.TextBox kgpz;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox precio;
        private System.Windows.Forms.TextBox caja;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox line;
        private System.Windows.Forms.ComboBox unid;
        private System.Windows.Forms.TextBox costo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox mede;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox med;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox listap;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox desclist;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox pcolist;
        private System.Windows.Forms.TextBox descrpnval;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox nvalistn;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox pallete;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox pallet;
        private System.Windows.Forms.TextBox sizele;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox sizel;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox lineadel;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label lincuan;
    }
}