﻿namespace CenezzInvoice
{
    partial class add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.alba = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.oridest = new System.Windows.Forms.TextBox();
            this.niff = new System.Windows.Forms.TextBox();
            this.pais = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.edo = new System.Windows.Forms.TextBox();
            this.mun = new System.Windows.Forms.TextBox();
            this.cd = new System.Windows.Forms.TextBox();
            this.col = new System.Windows.Forms.TextBox();
            this.numi = new System.Windows.Forms.TextBox();
            this.nume = new System.Windows.Forms.TextBox();
            this.dirrec = new System.Windows.Forms.TextBox();
            this.recnom = new System.Windows.Forms.TextBox();
            this.nomemp = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.folio = new System.Windows.Forms.TextBox();
            this.fecha = new System.Windows.Forms.DateTimePicker();
            this.recep = new System.Windows.Forms.TextBox();
            this.emit = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.cveadd = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cantadd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.containeradd = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.contains = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.containsadd = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.delref = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.addrows = new System.Windows.Forms.ListView();
            this.cantadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.claveadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.unidad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kgsbox = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.punit = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.totadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.containeradded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kgsrow = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pallets = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.idadded = new System.Windows.Forms.TextBox();
            this.totrefs = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.currency = new System.Windows.Forms.ComboBox();
            this.obs1 = new System.Windows.Forms.TextBox();
            this.obs2 = new System.Windows.Forms.TextBox();
            this.obs3 = new System.Windows.Forms.TextBox();
            this.obs4 = new System.Windows.Forms.TextBox();
            this.obs5 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.listpr = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.randcant = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.idser = new System.Windows.Forms.TextBox();
            this.precserv = new System.Windows.Forms.TextBox();
            this.addserv = new System.Windows.Forms.Button();
            this.cantserv = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.claveserv = new System.Windows.Forms.TextBox();
            this.delserv = new System.Windows.Forms.Button();
            this.serves = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.neto = new System.Windows.Forms.TextBox();
            this.bruto = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.logcontainer = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cue = new System.Windows.Forms.TextBox();
            this.palletkgs = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.kilose = new System.Windows.Forms.TextBox();
            this.kgboxx = new System.Windows.Forms.TextBox();
            this.palled = new System.Windows.Forms.TextBox();
            this.updt = new System.Windows.Forms.Button();
            this.cantedit = new System.Windows.Forms.TextBox();
            this.clavedit = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.deces = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deces)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.alba);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.oridest);
            this.groupBox1.Controls.Add(this.niff);
            this.groupBox1.Controls.Add(this.pais);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.edo);
            this.groupBox1.Controls.Add(this.mun);
            this.groupBox1.Controls.Add(this.cd);
            this.groupBox1.Controls.Add(this.col);
            this.groupBox1.Controls.Add(this.numi);
            this.groupBox1.Controls.Add(this.nume);
            this.groupBox1.Controls.Add(this.dirrec);
            this.groupBox1.Controls.Add(this.recnom);
            this.groupBox1.Controls.Add(this.nomemp);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.folio);
            this.groupBox1.Controls.Add(this.fecha);
            this.groupBox1.Controls.Add(this.recep);
            this.groupBox1.Controls.Add(this.emit);
            this.groupBox1.Location = new System.Drawing.Point(21, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(717, 148);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos generales";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(545, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(155, 16);
            this.label12.TabIndex = 27;
            this.label12.Text = "Fracción arancelaria:";
            // 
            // alba
            // 
            this.alba.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alba.Location = new System.Drawing.Point(547, 29);
            this.alba.Name = "alba";
            this.alba.Size = new System.Drawing.Size(154, 26);
            this.alba.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(418, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 16);
            this.label11.TabIndex = 25;
            this.label11.Text = "Origen/destino:";
            // 
            // oridest
            // 
            this.oridest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oridest.Location = new System.Drawing.Point(418, 115);
            this.oridest.Name = "oridest";
            this.oridest.Size = new System.Drawing.Size(286, 26);
            this.oridest.TabIndex = 24;
            // 
            // niff
            // 
            this.niff.Location = new System.Drawing.Point(418, 58);
            this.niff.Name = "niff";
            this.niff.ReadOnly = true;
            this.niff.Size = new System.Drawing.Size(121, 20);
            this.niff.TabIndex = 23;
            // 
            // pais
            // 
            this.pais.Location = new System.Drawing.Point(340, 123);
            this.pais.Name = "pais";
            this.pais.ReadOnly = true;
            this.pais.Size = new System.Drawing.Size(72, 20);
            this.pais.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(545, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Folio invoice:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(416, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Fecha invoice:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Dirección:";
            // 
            // edo
            // 
            this.edo.Location = new System.Drawing.Point(240, 123);
            this.edo.Name = "edo";
            this.edo.ReadOnly = true;
            this.edo.Size = new System.Drawing.Size(98, 20);
            this.edo.TabIndex = 18;
            // 
            // mun
            // 
            this.mun.Location = new System.Drawing.Point(127, 123);
            this.mun.Name = "mun";
            this.mun.ReadOnly = true;
            this.mun.Size = new System.Drawing.Size(111, 20);
            this.mun.TabIndex = 17;
            // 
            // cd
            // 
            this.cd.Location = new System.Drawing.Point(15, 123);
            this.cd.Name = "cd";
            this.cd.ReadOnly = true;
            this.cd.Size = new System.Drawing.Size(110, 20);
            this.cd.TabIndex = 16;
            // 
            // col
            // 
            this.col.Location = new System.Drawing.Point(127, 102);
            this.col.Name = "col";
            this.col.ReadOnly = true;
            this.col.Size = new System.Drawing.Size(285, 20);
            this.col.TabIndex = 15;
            // 
            // numi
            // 
            this.numi.Location = new System.Drawing.Point(68, 102);
            this.numi.Name = "numi";
            this.numi.ReadOnly = true;
            this.numi.Size = new System.Drawing.Size(57, 20);
            this.numi.TabIndex = 14;
            // 
            // nume
            // 
            this.nume.Location = new System.Drawing.Point(14, 102);
            this.nume.Name = "nume";
            this.nume.ReadOnly = true;
            this.nume.Size = new System.Drawing.Size(52, 20);
            this.nume.TabIndex = 13;
            // 
            // dirrec
            // 
            this.dirrec.Location = new System.Drawing.Point(68, 81);
            this.dirrec.Name = "dirrec";
            this.dirrec.ReadOnly = true;
            this.dirrec.Size = new System.Drawing.Size(344, 20);
            this.dirrec.TabIndex = 12;
            // 
            // recnom
            // 
            this.recnom.Location = new System.Drawing.Point(123, 57);
            this.recnom.Name = "recnom";
            this.recnom.ReadOnly = true;
            this.recnom.Size = new System.Drawing.Size(289, 20);
            this.recnom.TabIndex = 11;
            // 
            // nomemp
            // 
            this.nomemp.Location = new System.Drawing.Point(123, 29);
            this.nomemp.Name = "nomemp";
            this.nomemp.ReadOnly = true;
            this.nomemp.Size = new System.Drawing.Size(289, 20);
            this.nomemp.TabIndex = 10;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(94, 55);
            this.button7.Name = "button7";
            this.button7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button7.Size = new System.Drawing.Size(24, 24);
            this.button7.TabIndex = 9;
            this.button7.Text = "...";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(95, 27);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(24, 24);
            this.button6.TabIndex = 8;
            this.button6.Text = "...";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Cliente:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Empresa:";
            // 
            // folio
            // 
            this.folio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folio.Location = new System.Drawing.Point(547, 82);
            this.folio.Name = "folio";
            this.folio.Size = new System.Drawing.Size(157, 26);
            this.folio.TabIndex = 5;
            // 
            // fecha
            // 
            this.fecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.fecha.Location = new System.Drawing.Point(418, 29);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(121, 26);
            this.fecha.TabIndex = 1;
            // 
            // recep
            // 
            this.recep.Location = new System.Drawing.Point(64, 57);
            this.recep.Name = "recep";
            this.recep.Size = new System.Drawing.Size(25, 20);
            this.recep.TabIndex = 4;
            this.recep.Text = "1";
            this.recep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // emit
            // 
            this.emit.Location = new System.Drawing.Point(64, 29);
            this.emit.Name = "emit";
            this.emit.Size = new System.Drawing.Size(25, 20);
            this.emit.TabIndex = 3;
            this.emit.Text = "1";
            this.emit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.emit_KeyPress);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(746, 102);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Lime;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(716, 249);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(23, 26);
            this.button4.TabIndex = 5;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cveadd
            // 
            this.cveadd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cveadd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cveadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cveadd.Location = new System.Drawing.Point(28, 249);
            this.cveadd.Name = "cveadd";
            this.cveadd.Size = new System.Drawing.Size(185, 26);
            this.cveadd.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(746, 19);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(165, 77);
            this.button5.TabIndex = 7;
            this.button5.Text = "Guardar Invoice";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Clave:";
            // 
            // cantadd
            // 
            this.cantadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantadd.Location = new System.Drawing.Point(216, 249);
            this.cantadd.Name = "cantadd";
            this.cantadd.Size = new System.Drawing.Size(65, 26);
            this.cantadd.TabIndex = 22;
            this.cantadd.Text = "1.0";
            this.cantadd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(217, 234);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Cant m²:";
            // 
            // containeradd
            // 
            this.containeradd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.containeradd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containeradd.FormattingEnabled = true;
            this.containeradd.Location = new System.Drawing.Point(287, 249);
            this.containeradd.Name = "containeradd";
            this.containeradd.Size = new System.Drawing.Size(188, 26);
            this.containeradd.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(288, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Contenedor:";
            // 
            // contains
            // 
            this.contains.FormattingEnabled = true;
            this.contains.Location = new System.Drawing.Point(312, 166);
            this.contains.Name = "contains";
            this.contains.Size = new System.Drawing.Size(142, 69);
            this.contains.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 215);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Numero contenedor:";
            // 
            // containsadd
            // 
            this.containsadd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.containsadd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.containsadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containsadd.Location = new System.Drawing.Point(140, 207);
            this.containsadd.Name = "containsadd";
            this.containsadd.Size = new System.Drawing.Size(166, 26);
            this.containsadd.TabIndex = 26;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Lime;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(456, 167);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(23, 23);
            this.button8.TabIndex = 28;
            this.button8.Text = "+";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Red;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(456, 188);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(23, 23);
            this.button9.TabIndex = 29;
            this.button9.Text = "-";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // delref
            // 
            this.delref.BackColor = System.Drawing.Color.Red;
            this.delref.Enabled = false;
            this.delref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delref.Location = new System.Drawing.Point(693, 28);
            this.delref.Name = "delref";
            this.delref.Size = new System.Drawing.Size(23, 23);
            this.delref.TabIndex = 30;
            this.delref.Text = "-";
            this.delref.UseVisualStyleBackColor = false;
            this.delref.Click += new System.EventHandler(this.button10_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(311, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(119, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "Contenedores actuales:";
            // 
            // addrows
            // 
            this.addrows.BackgroundImageTiled = true;
            this.addrows.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cantadded,
            this.claveadded,
            this.unidad,
            this.kgsbox,
            this.punit,
            this.totadded,
            this.containeradded,
            this.kgsrow,
            this.pallets});
            this.addrows.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrows.FullRowSelect = true;
            this.addrows.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.addrows.Location = new System.Drawing.Point(28, 332);
            this.addrows.MultiSelect = false;
            this.addrows.Name = "addrows";
            this.addrows.Size = new System.Drawing.Size(711, 94);
            this.addrows.TabIndex = 136;
            this.addrows.TabStop = false;
            this.addrows.UseCompatibleStateImageBehavior = false;
            this.addrows.View = System.Windows.Forms.View.Details;
            this.addrows.SelectedIndexChanged += new System.EventHandler(this.addrows_SelectedIndexChanged);
            this.addrows.Click += new System.EventHandler(this.addrows_Click);
            // 
            // cantadded
            // 
            this.cantadded.Text = "Cant.";
            this.cantadded.Width = 50;
            // 
            // claveadded
            // 
            this.claveadded.Text = "Clave";
            this.claveadded.Width = 113;
            // 
            // unidad
            // 
            this.unidad.Text = "Und.";
            this.unidad.Width = 65;
            // 
            // kgsbox
            // 
            this.kgsbox.Text = "Kilos Caja";
            // 
            // punit
            // 
            this.punit.Text = "P. Unitario";
            this.punit.Width = 78;
            // 
            // totadded
            // 
            this.totadded.Text = "Importe";
            this.totadded.Width = 112;
            // 
            // containeradded
            // 
            this.containeradded.Text = "Container";
            this.containeradded.Width = 79;
            // 
            // kgsrow
            // 
            this.kgsrow.Text = "Kgs Tot";
            // 
            // pallets
            // 
            this.pallets.Text = "Pallets";
            // 
            // idadded
            // 
            this.idadded.Location = new System.Drawing.Point(7, 404);
            this.idadded.Name = "idadded";
            this.idadded.Size = new System.Drawing.Size(18, 20);
            this.idadded.TabIndex = 137;
            this.idadded.Visible = false;
            // 
            // totrefs
            // 
            this.totrefs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totrefs.Location = new System.Drawing.Point(752, 449);
            this.totrefs.Name = "totrefs";
            this.totrefs.ReadOnly = true;
            this.totrefs.Size = new System.Drawing.Size(159, 26);
            this.totrefs.TabIndex = 138;
            this.totrefs.Text = "0.00";
            this.totrefs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(34, 163);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 140;
            this.label13.Text = "Moneda:";
            // 
            // currency
            // 
            this.currency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.currency.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currency.FormattingEnabled = true;
            this.currency.Items.AddRange(new object[] {
            "USD",
            "EUR"});
            this.currency.Location = new System.Drawing.Point(31, 180);
            this.currency.Name = "currency";
            this.currency.Size = new System.Drawing.Size(102, 26);
            this.currency.TabIndex = 139;
            // 
            // obs1
            // 
            this.obs1.Location = new System.Drawing.Point(6, 21);
            this.obs1.Multiline = true;
            this.obs1.Name = "obs1";
            this.obs1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs1.Size = new System.Drawing.Size(153, 48);
            this.obs1.TabIndex = 28;
            // 
            // obs2
            // 
            this.obs2.Location = new System.Drawing.Point(6, 71);
            this.obs2.Multiline = true;
            this.obs2.Name = "obs2";
            this.obs2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs2.Size = new System.Drawing.Size(153, 48);
            this.obs2.TabIndex = 142;
            // 
            // obs3
            // 
            this.obs3.Location = new System.Drawing.Point(6, 121);
            this.obs3.Multiline = true;
            this.obs3.Name = "obs3";
            this.obs3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs3.Size = new System.Drawing.Size(153, 48);
            this.obs3.TabIndex = 143;
            // 
            // obs4
            // 
            this.obs4.Location = new System.Drawing.Point(6, 171);
            this.obs4.Multiline = true;
            this.obs4.Name = "obs4";
            this.obs4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs4.Size = new System.Drawing.Size(153, 48);
            this.obs4.TabIndex = 144;
            // 
            // obs5
            // 
            this.obs5.Location = new System.Drawing.Point(6, 221);
            this.obs5.Multiline = true;
            this.obs5.Name = "obs5";
            this.obs5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs5.Size = new System.Drawing.Size(153, 48);
            this.obs5.TabIndex = 145;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.obs2);
            this.groupBox2.Controls.Add(this.obs5);
            this.groupBox2.Controls.Add(this.obs1);
            this.groupBox2.Controls.Add(this.obs4);
            this.groupBox2.Controls.Add(this.obs3);
            this.groupBox2.Location = new System.Drawing.Point(746, 153);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(167, 276);
            this.groupBox2.TabIndex = 146;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Observaciones";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(481, 256);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 162;
            this.label14.Text = "Lista de precios:";
            // 
            // listpr
            // 
            this.listpr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listpr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listpr.FormattingEnabled = true;
            this.listpr.Location = new System.Drawing.Point(568, 249);
            this.listpr.Name = "listpr";
            this.listpr.Size = new System.Drawing.Size(142, 26);
            this.listpr.TabIndex = 148;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(185, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 13);
            this.label15.TabIndex = 164;
            this.label15.Text = "Generar # cont:";
            // 
            // randcant
            // 
            this.randcant.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.randcant.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.randcant.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.randcant.Location = new System.Drawing.Point(271, 151);
            this.randcant.Name = "randcant";
            this.randcant.Size = new System.Drawing.Size(33, 26);
            this.randcant.TabIndex = 163;
            this.randcant.Text = "3";
            this.randcant.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(140, 180);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(167, 26);
            this.button2.TabIndex = 165;
            this.button2.Text = "Crear # de contenedor(es)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // idser
            // 
            this.idser.Location = new System.Drawing.Point(13, 450);
            this.idser.Name = "idser";
            this.idser.Size = new System.Drawing.Size(12, 20);
            this.idser.TabIndex = 181;
            this.idser.Visible = false;
            // 
            // precserv
            // 
            this.precserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precserv.Location = new System.Drawing.Point(283, 427);
            this.precserv.Name = "precserv";
            this.precserv.Size = new System.Drawing.Size(90, 22);
            this.precserv.TabIndex = 180;
            this.precserv.Text = "1.0";
            // 
            // addserv
            // 
            this.addserv.BackColor = System.Drawing.Color.Lime;
            this.addserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addserv.Location = new System.Drawing.Point(379, 427);
            this.addserv.Name = "addserv";
            this.addserv.Size = new System.Drawing.Size(23, 23);
            this.addserv.TabIndex = 179;
            this.addserv.Text = "+";
            this.addserv.UseVisualStyleBackColor = false;
            this.addserv.Click += new System.EventHandler(this.addserv_Click);
            // 
            // cantserv
            // 
            this.cantserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantserv.Location = new System.Drawing.Point(232, 427);
            this.cantserv.Name = "cantserv";
            this.cantserv.Size = new System.Drawing.Size(45, 22);
            this.cantserv.TabIndex = 178;
            this.cantserv.Text = "1.0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 432);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 177;
            this.label17.Text = "Clave:";
            // 
            // claveserv
            // 
            this.claveserv.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.claveserv.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.claveserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.claveserv.Location = new System.Drawing.Point(68, 427);
            this.claveserv.Name = "claveserv";
            this.claveserv.Size = new System.Drawing.Size(158, 22);
            this.claveserv.TabIndex = 176;
            this.claveserv.TextChanged += new System.EventHandler(this.claveserv_TextChanged);
            // 
            // delserv
            // 
            this.delserv.BackColor = System.Drawing.Color.Red;
            this.delserv.Enabled = false;
            this.delserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delserv.Location = new System.Drawing.Point(405, 427);
            this.delserv.Name = "delserv";
            this.delserv.Size = new System.Drawing.Size(23, 23);
            this.delserv.TabIndex = 175;
            this.delserv.Text = "-";
            this.delserv.UseVisualStyleBackColor = false;
            this.delserv.Click += new System.EventHandler(this.delserv_Click);
            // 
            // serves
            // 
            this.serves.BackgroundImageTiled = true;
            this.serves.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.serves.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serves.FullRowSelect = true;
            this.serves.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.serves.Location = new System.Drawing.Point(27, 450);
            this.serves.MultiSelect = false;
            this.serves.Name = "serves";
            this.serves.Size = new System.Drawing.Size(711, 69);
            this.serves.TabIndex = 174;
            this.serves.TabStop = false;
            this.serves.UseCompatibleStateImageBehavior = false;
            this.serves.View = System.Windows.Forms.View.Details;
            this.serves.SelectedIndexChanged += new System.EventHandler(this.serves_SelectedIndexChanged);
            this.serves.Click += new System.EventHandler(this.serves_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Cant.";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Clave";
            this.columnHeader2.Width = 130;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Descripcion";
            this.columnHeader3.Width = 331;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "P. Unitario";
            this.columnHeader4.Width = 75;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Total";
            this.columnHeader5.Width = 99;
            // 
            // neto
            // 
            this.neto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neto.Location = new System.Drawing.Point(779, 477);
            this.neto.Name = "neto";
            this.neto.ReadOnly = true;
            this.neto.Size = new System.Drawing.Size(132, 26);
            this.neto.TabIndex = 188;
            this.neto.Text = "0.00";
            this.neto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bruto
            // 
            this.bruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bruto.Location = new System.Drawing.Point(779, 505);
            this.bruto.Name = "bruto";
            this.bruto.ReadOnly = true;
            this.bruto.Size = new System.Drawing.Size(132, 26);
            this.bruto.TabIndex = 189;
            this.bruto.Text = "0.00";
            this.bruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(747, 430);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(99, 16);
            this.label16.TabIndex = 190;
            this.label16.Text = "Total factura:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(747, 484);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 13);
            this.label18.TabIndex = 191;
            this.label18.Text = "Neto:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(747, 512);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 192;
            this.label19.Text = "Bruto:";
            // 
            // logcontainer
            // 
            this.logcontainer.Location = new System.Drawing.Point(484, 166);
            this.logcontainer.Multiline = true;
            this.logcontainer.Name = "logcontainer";
            this.logcontainer.ReadOnly = true;
            this.logcontainer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.logcontainer.Size = new System.Drawing.Size(252, 70);
            this.logcontainer.TabIndex = 269;
            this.logcontainer.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(487, 150);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(114, 13);
            this.label21.TabIndex = 270;
            this.label21.Text = "Pesos por contenedor:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(548, 15);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 307;
            this.label29.Text = "KgsTot";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(236, 14);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 306;
            this.label28.Text = "Kgs x caja.";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(612, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(36, 13);
            this.label27.TabIndex = 305;
            this.label27.Text = "Pallet.";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(295, 15);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 13);
            this.label26.TabIndex = 304;
            this.label26.Text = "Precio";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(8, 14);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 13);
            this.label25.TabIndex = 303;
            this.label25.Text = "Cant m²:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(60, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 13);
            this.label24.TabIndex = 302;
            this.label24.Text = "Clave";
            // 
            // cue
            // 
            this.cue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cue.Location = new System.Drawing.Point(298, 30);
            this.cue.Name = "cue";
            this.cue.Size = new System.Drawing.Size(77, 20);
            this.cue.TabIndex = 301;
            this.cue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cue_KeyPress);
            // 
            // palletkgs
            // 
            this.palletkgs.Location = new System.Drawing.Point(510, 30);
            this.palletkgs.Name = "palletkgs";
            this.palletkgs.ReadOnly = true;
            this.palletkgs.Size = new System.Drawing.Size(39, 20);
            this.palletkgs.TabIndex = 300;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(375, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(133, 13);
            this.label20.TabIndex = 299;
            this.label20.Text = "Kgs. tarima con embalajes:";
            // 
            // kilose
            // 
            this.kilose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilose.Location = new System.Drawing.Point(550, 30);
            this.kilose.Name = "kilose";
            this.kilose.Size = new System.Drawing.Size(63, 20);
            this.kilose.TabIndex = 298;
            this.kilose.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kilose_KeyPress_1);
            // 
            // kgboxx
            // 
            this.kgboxx.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kgboxx.Location = new System.Drawing.Point(239, 30);
            this.kgboxx.Name = "kgboxx";
            this.kgboxx.ReadOnly = true;
            this.kgboxx.Size = new System.Drawing.Size(56, 20);
            this.kgboxx.TabIndex = 297;
            // 
            // palled
            // 
            this.palled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palled.Location = new System.Drawing.Point(614, 30);
            this.palled.Name = "palled";
            this.palled.Size = new System.Drawing.Size(39, 20);
            this.palled.TabIndex = 296;
            this.palled.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.palled_KeyPress_1);
            // 
            // updt
            // 
            this.updt.BackColor = System.Drawing.Color.Lime;
            this.updt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updt.Location = new System.Drawing.Point(654, 29);
            this.updt.Name = "updt";
            this.updt.Size = new System.Drawing.Size(39, 22);
            this.updt.TabIndex = 295;
            this.updt.Text = "Actu";
            this.updt.UseVisualStyleBackColor = false;
            this.updt.Click += new System.EventHandler(this.updt_Click_1);
            // 
            // cantedit
            // 
            this.cantedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantedit.Location = new System.Drawing.Point(9, 30);
            this.cantedit.Name = "cantedit";
            this.cantedit.Size = new System.Drawing.Size(51, 20);
            this.cantedit.TabIndex = 294;
            this.cantedit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantedit_KeyPress_1);
            // 
            // clavedit
            // 
            this.clavedit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.clavedit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.clavedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clavedit.Location = new System.Drawing.Point(62, 30);
            this.clavedit.Name = "clavedit";
            this.clavedit.Size = new System.Drawing.Size(175, 20);
            this.clavedit.TabIndex = 293;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.kgboxx);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.clavedit);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.cantedit);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.updt);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.palled);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.kilose);
            this.groupBox3.Controls.Add(this.cue);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.palletkgs);
            this.groupBox3.Controls.Add(this.delref);
            this.groupBox3.Location = new System.Drawing.Point(21, 277);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(718, 55);
            this.groupBox3.TabIndex = 308;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Editar partida";
            // 
            // deces
            // 
            this.deces.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deces.Location = new System.Drawing.Point(879, 129);
            this.deces.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.deces.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.deces.Name = "deces";
            this.deces.Size = new System.Drawing.Size(32, 20);
            this.deces.TabIndex = 309;
            this.deces.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.deces.ValueChanged += new System.EventHandler(this.deces_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(808, 132);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 13);
            this.label22.TabIndex = 310;
            this.label22.Text = "Decimales:";
            // 
            // add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 660);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.deces);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.logcontainer);
            this.Controls.Add(this.neto);
            this.Controls.Add(this.bruto);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.idser);
            this.Controls.Add(this.precserv);
            this.Controls.Add(this.addserv);
            this.Controls.Add(this.cantserv);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.claveserv);
            this.Controls.Add(this.delserv);
            this.Controls.Add(this.serves);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.randcant);
            this.Controls.Add(this.listpr);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.currency);
            this.Controls.Add(this.totrefs);
            this.Controls.Add(this.idadded);
            this.Controls.Add(this.addrows);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.containsadd);
            this.Controls.Add(this.contains);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.containeradd);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cantadd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.cveadd);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "add";
            this.Text = "Nuevo Invoice";
            this.Deactivate += new System.EventHandler(this.add_Deactivate);
            this.Load += new System.EventHandler(this.add_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.add_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deces)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker fecha;
        private System.Windows.Forms.TextBox emit;
        private System.Windows.Forms.TextBox recep;
        private System.Windows.Forms.TextBox folio;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox cveadd;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox recnom;
        private System.Windows.Forms.TextBox nomemp;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox col;
        private System.Windows.Forms.TextBox numi;
        private System.Windows.Forms.TextBox nume;
        private System.Windows.Forms.TextBox dirrec;
        private System.Windows.Forms.TextBox edo;
        private System.Windows.Forms.TextBox mun;
        private System.Windows.Forms.TextBox cd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox cantadd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox containeradd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox contains;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox containsadd;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button delref;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListView addrows;
        private System.Windows.Forms.ColumnHeader cantadded;
        private System.Windows.Forms.ColumnHeader claveadded;
        private System.Windows.Forms.ColumnHeader unidad;
        private System.Windows.Forms.ColumnHeader punit;
        private System.Windows.Forms.ColumnHeader totadded;
        private System.Windows.Forms.ColumnHeader containeradded;
        private System.Windows.Forms.TextBox idadded;
        private System.Windows.Forms.TextBox totrefs;
        private System.Windows.Forms.TextBox pais;
        private System.Windows.Forms.TextBox niff;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox oridest;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox alba;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox currency;
        private System.Windows.Forms.TextBox obs1;
        private System.Windows.Forms.TextBox obs2;
        private System.Windows.Forms.TextBox obs3;
        private System.Windows.Forms.TextBox obs4;
        private System.Windows.Forms.TextBox obs5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox listpr;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox randcant;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox idser;
        private System.Windows.Forms.TextBox precserv;
        private System.Windows.Forms.Button addserv;
        private System.Windows.Forms.TextBox cantserv;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox claveserv;
        private System.Windows.Forms.Button delserv;
        private System.Windows.Forms.ListView serves;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader pallets;
        private System.Windows.Forms.ColumnHeader kgsbox;
        private System.Windows.Forms.ColumnHeader kgsrow;
        private System.Windows.Forms.TextBox neto;
        private System.Windows.Forms.TextBox bruto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox logcontainer;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox cue;
        private System.Windows.Forms.TextBox palletkgs;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox kilose;
        private System.Windows.Forms.TextBox kgboxx;
        private System.Windows.Forms.TextBox palled;
        private System.Windows.Forms.Button updt;
        private System.Windows.Forms.TextBox cantedit;
        private System.Windows.Forms.TextBox clavedit;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown deces;
        private System.Windows.Forms.Label label22;
    }
}