﻿namespace CenezzInvoice
{
    partial class configui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(configui));
            this.label3 = new System.Windows.Forms.Label();
            this.palletkgs = new System.Windows.Forms.TextBox();
            this.obs3 = new System.Windows.Forms.TextBox();
            this.obs4 = new System.Windows.Forms.TextBox();
            this.obs1 = new System.Windows.Forms.TextBox();
            this.obs5 = new System.Windows.Forms.TextBox();
            this.obs2 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dbs = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.sufix = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.prefix = new System.Windows.Forms.TextBox();
            this.puerto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ip = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.user = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.uuid = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ejer = new System.Windows.Forms.ComboBox();
            this.savefolio = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.folio = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(256, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(275, 23);
            this.label3.TabIndex = 256;
            this.label3.Text = "Configuración y parametros";
            // 
            // palletkgs
            // 
            this.palletkgs.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.palletkgs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.palletkgs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palletkgs.Location = new System.Drawing.Point(6, 44);
            this.palletkgs.Name = "palletkgs";
            this.palletkgs.Size = new System.Drawing.Size(158, 26);
            this.palletkgs.TabIndex = 257;
            this.palletkgs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cveadd_KeyPress);
            // 
            // obs3
            // 
            this.obs3.Location = new System.Drawing.Point(6, 142);
            this.obs3.Multiline = true;
            this.obs3.Name = "obs3";
            this.obs3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs3.Size = new System.Drawing.Size(333, 61);
            this.obs3.TabIndex = 143;
            // 
            // obs4
            // 
            this.obs4.Location = new System.Drawing.Point(6, 205);
            this.obs4.Multiline = true;
            this.obs4.Name = "obs4";
            this.obs4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs4.Size = new System.Drawing.Size(333, 61);
            this.obs4.TabIndex = 144;
            // 
            // obs1
            // 
            this.obs1.Location = new System.Drawing.Point(6, 16);
            this.obs1.Multiline = true;
            this.obs1.Name = "obs1";
            this.obs1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs1.Size = new System.Drawing.Size(333, 61);
            this.obs1.TabIndex = 28;
            // 
            // obs5
            // 
            this.obs5.Location = new System.Drawing.Point(6, 268);
            this.obs5.Multiline = true;
            this.obs5.Name = "obs5";
            this.obs5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs5.Size = new System.Drawing.Size(333, 61);
            this.obs5.TabIndex = 145;
            // 
            // obs2
            // 
            this.obs2.Location = new System.Drawing.Point(6, 79);
            this.obs2.Multiline = true;
            this.obs2.Name = "obs2";
            this.obs2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs2.Size = new System.Drawing.Size(333, 61);
            this.obs2.TabIndex = 142;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.obs2);
            this.groupBox2.Controls.Add(this.obs5);
            this.groupBox2.Controls.Add(this.obs1);
            this.groupBox2.Controls.Add(this.obs4);
            this.groupBox2.Controls.Add(this.obs3);
            this.groupBox2.Location = new System.Drawing.Point(12, 35);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(345, 338);
            this.groupBox2.TabIndex = 147;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Observaciones";
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(554, 59);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(111, 77);
            this.button5.TabIndex = 146;
            this.button5.Text = "Guardar";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(674, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 77);
            this.button1.TabIndex = 259;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 261;
            this.label1.Text = "Peso de un pallet (Kgs):";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.palletkgs);
            this.groupBox1.Location = new System.Drawing.Point(363, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(185, 91);
            this.groupBox1.TabIndex = 262;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pesos de taras";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dbs);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.sufix);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.prefix);
            this.groupBox3.Controls.Add(this.puerto);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.pass);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.ip);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.user);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(363, 207);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(422, 166);
            this.groupBox3.TabIndex = 263;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Conexión a DB";
            // 
            // dbs
            // 
            this.dbs.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.dbs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.dbs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dbs.Location = new System.Drawing.Point(152, 35);
            this.dbs.Name = "dbs";
            this.dbs.Size = new System.Drawing.Size(140, 26);
            this.dbs.TabIndex = 270;
            this.dbs.Text = "1433";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(295, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 271;
            this.label9.Text = "Puerto:";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(298, 73);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 77);
            this.button2.TabIndex = 264;
            this.button2.Text = "Guardar conexión";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(149, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 269;
            this.label7.Text = "Sufijo tablas:";
            // 
            // sufix
            // 
            this.sufix.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sufix.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.sufix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sufix.Location = new System.Drawing.Point(152, 124);
            this.sufix.Name = "sufix";
            this.sufix.PasswordChar = '*';
            this.sufix.Size = new System.Drawing.Size(140, 26);
            this.sufix.TabIndex = 268;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 267;
            this.label8.Text = "Prefijo tablas:";
            // 
            // prefix
            // 
            this.prefix.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.prefix.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.prefix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prefix.Location = new System.Drawing.Point(6, 124);
            this.prefix.Name = "prefix";
            this.prefix.Size = new System.Drawing.Size(140, 26);
            this.prefix.TabIndex = 266;
            this.prefix.Text = "dbo";
            // 
            // puerto
            // 
            this.puerto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.puerto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.puerto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.puerto.Location = new System.Drawing.Point(298, 35);
            this.puerto.Name = "puerto";
            this.puerto.Size = new System.Drawing.Size(111, 26);
            this.puerto.TabIndex = 263;
            this.puerto.Text = "1433";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(149, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 265;
            this.label5.Text = "Password:";
            // 
            // pass
            // 
            this.pass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.Location = new System.Drawing.Point(152, 80);
            this.pass.Name = "pass";
            this.pass.PasswordChar = '*';
            this.pass.Size = new System.Drawing.Size(140, 26);
            this.pass.TabIndex = 262;
            this.pass.Text = "******";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(149, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 264;
            this.label6.Text = "Nombre de la base:";
            // 
            // ip
            // 
            this.ip.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ip.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ip.Location = new System.Drawing.Point(6, 35);
            this.ip.Name = "ip";
            this.ip.Size = new System.Drawing.Size(140, 26);
            this.ip.TabIndex = 258;
            this.ip.Text = "127.0.0.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 261;
            this.label2.Text = "User:";
            // 
            // user
            // 
            this.user.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.user.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.user.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user.Location = new System.Drawing.Point(6, 80);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(140, 26);
            this.user.TabIndex = 257;
            this.user.Text = "sa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 260;
            this.label4.Text = "IP del server:";
            // 
            // uuid
            // 
            this.uuid.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.uuid.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.uuid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uuid.Location = new System.Drawing.Point(554, 27);
            this.uuid.Name = "uuid";
            this.uuid.Size = new System.Drawing.Size(19, 26);
            this.uuid.TabIndex = 262;
            this.uuid.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ejer);
            this.groupBox4.Controls.Add(this.savefolio);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.folio);
            this.groupBox4.Location = new System.Drawing.Point(363, 142);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(422, 59);
            this.groupBox4.TabIndex = 263;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parametros de folios";
            this.groupBox4.Visible = false;
            // 
            // ejer
            // 
            this.ejer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ejer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ejer.FormattingEnabled = true;
            this.ejer.Location = new System.Drawing.Point(88, 20);
            this.ejer.Name = "ejer";
            this.ejer.Size = new System.Drawing.Size(121, 24);
            this.ejer.TabIndex = 273;
            this.ejer.SelectedIndexChanged += new System.EventHandler(this.ejer_SelectedIndexChanged);
            // 
            // savefolio
            // 
            this.savefolio.Enabled = false;
            this.savefolio.Image = ((System.Drawing.Image)(resources.GetObject("savefolio.Image")));
            this.savefolio.Location = new System.Drawing.Point(339, 12);
            this.savefolio.Name = "savefolio";
            this.savefolio.Size = new System.Drawing.Size(74, 46);
            this.savefolio.TabIndex = 272;
            this.savefolio.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.savefolio.UseVisualStyleBackColor = true;
            this.savefolio.Click += new System.EventHandler(this.savefolio_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 13);
            this.label10.TabIndex = 261;
            this.label10.Text = "Ejercicio/folio:";
            // 
            // folio
            // 
            this.folio.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.folio.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.folio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folio.Location = new System.Drawing.Point(212, 19);
            this.folio.Name = "folio";
            this.folio.Size = new System.Drawing.Size(119, 26);
            this.folio.TabIndex = 257;
            this.folio.TextChanged += new System.EventHandler(this.folio_TextChanged);
            this.folio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.folio_KeyPress);
            // 
            // configui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 379);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.uuid);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "configui";
            this.Text = "Panel de configuraciones";
            this.Deactivate += new System.EventHandler(this.configui_Deactivate);
            this.Load += new System.EventHandler(this.configui_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.configui_KeyUp);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox palletkgs;
        private System.Windows.Forms.TextBox obs3;
        private System.Windows.Forms.TextBox obs4;
        private System.Windows.Forms.TextBox obs1;
        private System.Windows.Forms.TextBox obs5;
        private System.Windows.Forms.TextBox obs2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox puerto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ip;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox user;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox sufix;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox prefix;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox uuid;
        private System.Windows.Forms.TextBox dbs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox ejer;
        private System.Windows.Forms.Button savefolio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox folio;
    }
}