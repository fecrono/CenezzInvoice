﻿namespace CenezzInvoice
{
    partial class gastos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(gastos));
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.descr = new System.Windows.Forms.TextBox();
            this.cve = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.precio = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.precioe = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.descre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cvee = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.idinvo = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.cves = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lister = new System.Windows.Forms.DataGridView();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lister)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(689, 11);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(132, 23);
            this.button3.TabIndex = 319;
            this.button3.Text = "Salir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.descr);
            this.groupBox3.Controls.Add(this.cve);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.precio);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Location = new System.Drawing.Point(414, 270);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(407, 97);
            this.groupBox3.TabIndex = 318;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Nuevo";
            // 
            // button4
            // 
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(308, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(93, 76);
            this.button4.TabIndex = 313;
            this.button4.Text = "Guardar Articulo";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // descr
            // 
            this.descr.Location = new System.Drawing.Point(48, 58);
            this.descr.Name = "descr";
            this.descr.Size = new System.Drawing.Size(256, 20);
            this.descr.TabIndex = 293;
            this.descr.TabStop = false;
            // 
            // cve
            // 
            this.cve.Location = new System.Drawing.Point(48, 25);
            this.cve.Name = "cve";
            this.cve.Size = new System.Drawing.Size(106, 20);
            this.cve.TabIndex = 289;
            this.cve.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(8, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 13);
            this.label26.TabIndex = 291;
            this.label26.Text = "Clave:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 62);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 13);
            this.label25.TabIndex = 294;
            this.label25.Text = "Descr:";
            // 
            // precio
            // 
            this.precio.Location = new System.Drawing.Point(210, 25);
            this.precio.Name = "precio";
            this.precio.Size = new System.Drawing.Size(94, 20);
            this.precio.TabIndex = 297;
            this.precio.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(166, 29);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 13);
            this.label23.TabIndex = 298;
            this.label23.Text = "Precio:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.precioe);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.descre);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cvee);
            this.groupBox2.Location = new System.Drawing.Point(13, 270);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(396, 97);
            this.groupBox2.TabIndex = 317;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Editar";
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(293, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(97, 73);
            this.button5.TabIndex = 312;
            this.button5.Text = "Guardar Cambios";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(164, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 276;
            this.label10.Text = "Precio:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // precioe
            // 
            this.precioe.Location = new System.Drawing.Point(206, 25);
            this.precioe.Name = "precioe";
            this.precioe.Size = new System.Drawing.Size(75, 20);
            this.precioe.TabIndex = 275;
            this.precioe.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 270;
            this.label7.Text = "Descr:";
            // 
            // descre
            // 
            this.descre.Location = new System.Drawing.Point(47, 58);
            this.descre.Name = "descre";
            this.descre.Size = new System.Drawing.Size(240, 20);
            this.descre.TabIndex = 269;
            this.descre.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 268;
            this.label2.Text = "Clave:";
            // 
            // cvee
            // 
            this.cvee.Location = new System.Drawing.Point(47, 25);
            this.cvee.Name = "cvee";
            this.cvee.ReadOnly = true;
            this.cvee.Size = new System.Drawing.Size(106, 20);
            this.cvee.TabIndex = 267;
            this.cvee.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(285, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(283, 23);
            this.label3.TabIndex = 316;
            this.label3.Text = "Servicios y gastos indirectos";
            // 
            // idinvo
            // 
            this.idinvo.Location = new System.Drawing.Point(658, 11);
            this.idinvo.Name = "idinvo";
            this.idinvo.Size = new System.Drawing.Size(25, 20);
            this.idinvo.TabIndex = 315;
            this.idinvo.TabStop = false;
            this.idinvo.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.cves);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(12, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 115);
            this.groupBox1.TabIndex = 314;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Herramientas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 258;
            this.label4.Text = "Clave:";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(197, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 79);
            this.button2.TabIndex = 264;
            this.button2.Text = "Eliminar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cves
            // 
            this.cves.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cves.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cves.Location = new System.Drawing.Point(49, 19);
            this.cves.Name = "cves";
            this.cves.Size = new System.Drawing.Size(142, 20);
            this.cves.TabIndex = 257;
            this.cves.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Image = global::CenezzInvoice.Properties.Resources.mail_find;
            this.button1.Location = new System.Drawing.Point(12, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 58);
            this.button1.TabIndex = 1;
            this.button1.Text = "Buscar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lister
            // 
            this.lister.AllowUserToAddRows = false;
            this.lister.AllowUserToDeleteRows = false;
            this.lister.AllowUserToResizeRows = false;
            this.lister.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.lister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lister.Location = new System.Drawing.Point(12, 158);
            this.lister.MultiSelect = false;
            this.lister.Name = "lister";
            this.lister.ReadOnly = true;
            this.lister.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.lister.RowHeadersVisible = false;
            this.lister.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.lister.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.lister.Size = new System.Drawing.Size(809, 109);
            this.lister.TabIndex = 313;
            this.lister.TabStop = false;
            this.lister.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.lister_CellClick);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(107, 383);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(58, 26);
            this.button6.TabIndex = 320;
            this.button6.Text = "Pivot";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // gastos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 519);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idinvo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lister);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "gastos";
            this.Text = "Catalogo de gastos indirectos";
            this.Deactivate += new System.EventHandler(this.gastos_Deactivate);
            this.Load += new System.EventHandler(this.gastos_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gastos_KeyUp);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lister)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox descr;
        private System.Windows.Forms.TextBox cve;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox precio;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox precioe;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox descre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox cvee;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox idinvo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox cves;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView lister;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button6;
    }
}