﻿namespace CenezzInvoice
{
    partial class editor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(editor));
            this.idadded = new System.Windows.Forms.TextBox();
            this.delref = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.containsadd = new System.Windows.Forms.TextBox();
            this.contains = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.containeradd = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cantadd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.cveadd = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.foliaje = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.alba = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.oridest = new System.Windows.Forms.TextBox();
            this.niff = new System.Windows.Forms.TextBox();
            this.pais = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.edo = new System.Windows.Forms.TextBox();
            this.mun = new System.Windows.Forms.TextBox();
            this.cd = new System.Windows.Forms.TextBox();
            this.col = new System.Windows.Forms.TextBox();
            this.numi = new System.Windows.Forms.TextBox();
            this.nume = new System.Windows.Forms.TextBox();
            this.dirrec = new System.Windows.Forms.TextBox();
            this.recnom = new System.Windows.Forms.TextBox();
            this.nomemp = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.currency = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.folio = new System.Windows.Forms.TextBox();
            this.fecha = new System.Windows.Forms.DateTimePicker();
            this.recep = new System.Windows.Forms.TextBox();
            this.emit = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.obs2 = new System.Windows.Forms.TextBox();
            this.obs5 = new System.Windows.Forms.TextBox();
            this.obs1 = new System.Windows.Forms.TextBox();
            this.obs4 = new System.Windows.Forms.TextBox();
            this.obs3 = new System.Windows.Forms.TextBox();
            this.listpr = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.updtc = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.nucon = new System.Windows.Forms.TextBox();
            this.serves = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.delserv = new System.Windows.Forms.Button();
            this.cantserv = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.claveserv = new System.Windows.Forms.TextBox();
            this.addserv = new System.Windows.Forms.Button();
            this.precserv = new System.Windows.Forms.TextBox();
            this.idser = new System.Windows.Forms.TextBox();
            this.preci = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.updt = new System.Windows.Forms.Button();
            this.cantedit = new System.Windows.Forms.TextBox();
            this.clavedit = new System.Windows.Forms.TextBox();
            this.palled = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.logcontainer = new System.Windows.Forms.TextBox();
            this.kilose = new System.Windows.Forms.TextBox();
            this.kgboxx = new System.Windows.Forms.TextBox();
            this.palletkgs = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.neto = new System.Windows.Forms.TextBox();
            this.bruto = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.totrefs = new System.Windows.Forms.TextBox();
            this.addrows = new System.Windows.Forms.ListView();
            this.cantadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.claveadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.unidad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kgsbox = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.punit = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.totadded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.containeradded = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kgsrow = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pallets = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.states = new System.Windows.Forms.Label();
            this.cue = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // idadded
            // 
            this.idadded.Location = new System.Drawing.Point(4, 338);
            this.idadded.Name = "idadded";
            this.idadded.Size = new System.Drawing.Size(12, 20);
            this.idadded.TabIndex = 157;
            this.idadded.Visible = false;
            // 
            // delref
            // 
            this.delref.BackColor = System.Drawing.Color.Red;
            this.delref.Enabled = false;
            this.delref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delref.Location = new System.Drawing.Point(705, 26);
            this.delref.Name = "delref";
            this.delref.Size = new System.Drawing.Size(23, 22);
            this.delref.TabIndex = 154;
            this.delref.Text = "-";
            this.delref.UseVisualStyleBackColor = false;
            this.delref.Click += new System.EventHandler(this.delref_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Red;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(429, 156);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(23, 23);
            this.button9.TabIndex = 153;
            this.button9.Text = "-";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Lime;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(250, 159);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(26, 23);
            this.button8.TabIndex = 152;
            this.button8.Text = "+";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 13);
            this.label9.TabIndex = 151;
            this.label9.Text = "Nuevo contenedor:";
            // 
            // containsadd
            // 
            this.containsadd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.containsadd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.containsadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containsadd.Location = new System.Drawing.Point(118, 157);
            this.containsadd.Name = "containsadd";
            this.containsadd.Size = new System.Drawing.Size(129, 26);
            this.containsadd.TabIndex = 150;
            // 
            // contains
            // 
            this.contains.FormattingEnabled = true;
            this.contains.Location = new System.Drawing.Point(282, 157);
            this.contains.Name = "contains";
            this.contains.Size = new System.Drawing.Size(145, 82);
            this.contains.TabIndex = 149;
            this.contains.SelectedIndexChanged += new System.EventHandler(this.contains_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(277, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 148;
            this.label8.Text = "Contenedor:";
            // 
            // containeradd
            // 
            this.containeradd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.containeradd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containeradd.FormattingEnabled = true;
            this.containeradd.Location = new System.Drawing.Point(275, 253);
            this.containeradd.Name = "containeradd";
            this.containeradd.Size = new System.Drawing.Size(176, 26);
            this.containeradd.TabIndex = 146;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(209, 238);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 147;
            this.label7.Text = "Cant m²:";
            // 
            // cantadd
            // 
            this.cantadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantadd.Location = new System.Drawing.Point(207, 253);
            this.cantadd.Name = "cantadd";
            this.cantadd.Size = new System.Drawing.Size(65, 26);
            this.cantadd.TabIndex = 145;
            this.cantadd.Text = "1.0";
            this.cantadd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantadd_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 144;
            this.label6.Text = "Clave:";
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(731, 32);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(196, 71);
            this.button5.TabIndex = 143;
            this.button5.Text = "Actualizar Invoice";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // cveadd
            // 
            this.cveadd.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cveadd.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.cveadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cveadd.Location = new System.Drawing.Point(14, 253);
            this.cveadd.Name = "cveadd";
            this.cveadd.Size = new System.Drawing.Size(190, 26);
            this.cveadd.TabIndex = 142;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Lime;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(708, 252);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(23, 28);
            this.button4.TabIndex = 141;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(731, 106);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 23);
            this.button1.TabIndex = 140;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.foliaje);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.alba);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.oridest);
            this.groupBox1.Controls.Add(this.niff);
            this.groupBox1.Controls.Add(this.pais);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.edo);
            this.groupBox1.Controls.Add(this.mun);
            this.groupBox1.Controls.Add(this.cd);
            this.groupBox1.Controls.Add(this.col);
            this.groupBox1.Controls.Add(this.numi);
            this.groupBox1.Controls.Add(this.nume);
            this.groupBox1.Controls.Add(this.dirrec);
            this.groupBox1.Controls.Add(this.recnom);
            this.groupBox1.Controls.Add(this.nomemp);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.currency);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.folio);
            this.groupBox1.Controls.Add(this.fecha);
            this.groupBox1.Controls.Add(this.recep);
            this.groupBox1.Controls.Add(this.emit);
            this.groupBox1.Location = new System.Drawing.Point(9, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(712, 157);
            this.groupBox1.TabIndex = 139;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos generales";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(420, 81);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 16);
            this.label15.TabIndex = 29;
            this.label15.Text = "Número:";
            // 
            // foliaje
            // 
            this.foliaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foliaje.Location = new System.Drawing.Point(421, 100);
            this.foliaje.Name = "foliaje";
            this.foliaje.ReadOnly = true;
            this.foliaje.Size = new System.Drawing.Size(121, 26);
            this.foliaje.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(547, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(155, 16);
            this.label12.TabIndex = 27;
            this.label12.Text = "Fracción arancelaria:";
            // 
            // alba
            // 
            this.alba.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alba.Location = new System.Drawing.Point(549, 29);
            this.alba.Name = "alba";
            this.alba.Size = new System.Drawing.Size(153, 26);
            this.alba.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 15);
            this.label11.TabIndex = 25;
            this.label11.Text = "Origen/destino:";
            // 
            // oridest
            // 
            this.oridest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oridest.Location = new System.Drawing.Point(126, 129);
            this.oridest.Name = "oridest";
            this.oridest.Size = new System.Drawing.Size(574, 21);
            this.oridest.TabIndex = 24;
            // 
            // niff
            // 
            this.niff.Location = new System.Drawing.Point(420, 60);
            this.niff.Name = "niff";
            this.niff.ReadOnly = true;
            this.niff.Size = new System.Drawing.Size(120, 20);
            this.niff.TabIndex = 23;
            // 
            // pais
            // 
            this.pais.Location = new System.Drawing.Point(335, 108);
            this.pais.Name = "pais";
            this.pais.ReadOnly = true;
            this.pais.Size = new System.Drawing.Size(76, 20);
            this.pais.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(546, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Folio invoice:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(420, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Fecha invoice:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Dirección:";
            // 
            // edo
            // 
            this.edo.Location = new System.Drawing.Point(239, 108);
            this.edo.Name = "edo";
            this.edo.ReadOnly = true;
            this.edo.Size = new System.Drawing.Size(94, 20);
            this.edo.TabIndex = 18;
            // 
            // mun
            // 
            this.mun.Location = new System.Drawing.Point(126, 108);
            this.mun.Name = "mun";
            this.mun.ReadOnly = true;
            this.mun.Size = new System.Drawing.Size(110, 20);
            this.mun.TabIndex = 17;
            // 
            // cd
            // 
            this.cd.Location = new System.Drawing.Point(13, 108);
            this.cd.Name = "cd";
            this.cd.ReadOnly = true;
            this.cd.Size = new System.Drawing.Size(110, 20);
            this.cd.TabIndex = 16;
            // 
            // col
            // 
            this.col.Location = new System.Drawing.Point(126, 87);
            this.col.Name = "col";
            this.col.ReadOnly = true;
            this.col.Size = new System.Drawing.Size(285, 20);
            this.col.TabIndex = 15;
            // 
            // numi
            // 
            this.numi.Location = new System.Drawing.Point(69, 87);
            this.numi.Name = "numi";
            this.numi.ReadOnly = true;
            this.numi.Size = new System.Drawing.Size(54, 20);
            this.numi.TabIndex = 14;
            // 
            // nume
            // 
            this.nume.Location = new System.Drawing.Point(13, 87);
            this.nume.Name = "nume";
            this.nume.ReadOnly = true;
            this.nume.Size = new System.Drawing.Size(54, 20);
            this.nume.TabIndex = 13;
            // 
            // dirrec
            // 
            this.dirrec.Location = new System.Drawing.Point(69, 66);
            this.dirrec.Name = "dirrec";
            this.dirrec.ReadOnly = true;
            this.dirrec.Size = new System.Drawing.Size(342, 20);
            this.dirrec.TabIndex = 12;
            // 
            // recnom
            // 
            this.recnom.Location = new System.Drawing.Point(125, 44);
            this.recnom.Name = "recnom";
            this.recnom.ReadOnly = true;
            this.recnom.Size = new System.Drawing.Size(286, 20);
            this.recnom.TabIndex = 11;
            // 
            // nomemp
            // 
            this.nomemp.Location = new System.Drawing.Point(125, 22);
            this.nomemp.Name = "nomemp";
            this.nomemp.ReadOnly = true;
            this.nomemp.Size = new System.Drawing.Size(286, 20);
            this.nomemp.TabIndex = 10;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(99, 43);
            this.button7.Name = "button7";
            this.button7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button7.Size = new System.Drawing.Size(24, 22);
            this.button7.TabIndex = 9;
            this.button7.Text = "...";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(547, 65);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 13);
            this.label13.TabIndex = 142;
            this.label13.Text = "Moneda:";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(99, 21);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(24, 22);
            this.button6.TabIndex = 8;
            this.button6.Text = "...";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Cliente:";
            // 
            // currency
            // 
            this.currency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.currency.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currency.FormattingEnabled = true;
            this.currency.Items.AddRange(new object[] {
            "USD",
            "EUR"});
            this.currency.Location = new System.Drawing.Point(608, 58);
            this.currency.Name = "currency";
            this.currency.Size = new System.Drawing.Size(94, 26);
            this.currency.TabIndex = 141;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Empresa:";
            // 
            // folio
            // 
            this.folio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.folio.Location = new System.Drawing.Point(549, 100);
            this.folio.Name = "folio";
            this.folio.Size = new System.Drawing.Size(151, 26);
            this.folio.TabIndex = 5;
            // 
            // fecha
            // 
            this.fecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.fecha.Location = new System.Drawing.Point(421, 29);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(119, 26);
            this.fecha.TabIndex = 1;
            // 
            // recep
            // 
            this.recep.Location = new System.Drawing.Point(69, 44);
            this.recep.Name = "recep";
            this.recep.Size = new System.Drawing.Size(25, 20);
            this.recep.TabIndex = 4;
            this.recep.Text = "1";
            // 
            // emit
            // 
            this.emit.Location = new System.Drawing.Point(69, 22);
            this.emit.Name = "emit";
            this.emit.Size = new System.Drawing.Size(25, 20);
            this.emit.TabIndex = 3;
            this.emit.Text = "1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.obs2);
            this.groupBox2.Controls.Add(this.obs5);
            this.groupBox2.Controls.Add(this.obs1);
            this.groupBox2.Controls.Add(this.obs4);
            this.groupBox2.Controls.Add(this.obs3);
            this.groupBox2.Location = new System.Drawing.Point(735, 130);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(192, 276);
            this.groupBox2.TabIndex = 159;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Observaciones";
            // 
            // obs2
            // 
            this.obs2.Location = new System.Drawing.Point(6, 71);
            this.obs2.Multiline = true;
            this.obs2.Name = "obs2";
            this.obs2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs2.Size = new System.Drawing.Size(180, 48);
            this.obs2.TabIndex = 142;
            // 
            // obs5
            // 
            this.obs5.Location = new System.Drawing.Point(6, 221);
            this.obs5.Multiline = true;
            this.obs5.Name = "obs5";
            this.obs5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs5.Size = new System.Drawing.Size(180, 48);
            this.obs5.TabIndex = 145;
            // 
            // obs1
            // 
            this.obs1.Location = new System.Drawing.Point(6, 21);
            this.obs1.Multiline = true;
            this.obs1.Name = "obs1";
            this.obs1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs1.Size = new System.Drawing.Size(180, 48);
            this.obs1.TabIndex = 28;
            // 
            // obs4
            // 
            this.obs4.Location = new System.Drawing.Point(6, 171);
            this.obs4.Multiline = true;
            this.obs4.Name = "obs4";
            this.obs4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs4.Size = new System.Drawing.Size(180, 48);
            this.obs4.TabIndex = 144;
            // 
            // obs3
            // 
            this.obs3.Location = new System.Drawing.Point(6, 121);
            this.obs3.Multiline = true;
            this.obs3.Name = "obs3";
            this.obs3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.obs3.Size = new System.Drawing.Size(180, 48);
            this.obs3.TabIndex = 143;
            // 
            // listpr
            // 
            this.listpr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listpr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listpr.FormattingEnabled = true;
            this.listpr.Location = new System.Drawing.Point(542, 253);
            this.listpr.Name = "listpr";
            this.listpr.Size = new System.Drawing.Size(163, 26);
            this.listpr.TabIndex = 160;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(454, 260);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 161;
            this.label14.Text = "Lista de precios:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(39, 191);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 13);
            this.label16.TabIndex = 163;
            this.label16.Text = "Editar número:";
            // 
            // updtc
            // 
            this.updtc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.updtc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.updtc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updtc.Location = new System.Drawing.Point(118, 184);
            this.updtc.Name = "updtc";
            this.updtc.Size = new System.Drawing.Size(129, 26);
            this.updtc.TabIndex = 162;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(250, 185);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(26, 25);
            this.button2.TabIndex = 164;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // nucon
            // 
            this.nucon.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.nucon.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.nucon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nucon.Location = new System.Drawing.Point(430, 180);
            this.nucon.Name = "nucon";
            this.nucon.Size = new System.Drawing.Size(15, 20);
            this.nucon.TabIndex = 165;
            this.nucon.Visible = false;
            // 
            // serves
            // 
            this.serves.BackgroundImageTiled = true;
            this.serves.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.serves.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serves.FullRowSelect = true;
            this.serves.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.serves.Location = new System.Drawing.Point(18, 463);
            this.serves.MultiSelect = false;
            this.serves.Name = "serves";
            this.serves.Size = new System.Drawing.Size(711, 59);
            this.serves.TabIndex = 166;
            this.serves.TabStop = false;
            this.serves.UseCompatibleStateImageBehavior = false;
            this.serves.View = System.Windows.Forms.View.Details;
            this.serves.SelectedIndexChanged += new System.EventHandler(this.serves_SelectedIndexChanged);
            this.serves.Click += new System.EventHandler(this.serves_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Cant.";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Clave";
            this.columnHeader2.Width = 130;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Descripcion";
            this.columnHeader3.Width = 328;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "P. Unitario";
            this.columnHeader4.Width = 75;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Total";
            this.columnHeader5.Width = 99;
            // 
            // delserv
            // 
            this.delserv.BackColor = System.Drawing.Color.Red;
            this.delserv.Enabled = false;
            this.delserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delserv.Location = new System.Drawing.Point(399, 440);
            this.delserv.Name = "delserv";
            this.delserv.Size = new System.Drawing.Size(23, 23);
            this.delserv.TabIndex = 167;
            this.delserv.Text = "-";
            this.delserv.UseVisualStyleBackColor = false;
            this.delserv.Click += new System.EventHandler(this.button3_Click);
            // 
            // cantserv
            // 
            this.cantserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantserv.Location = new System.Drawing.Point(223, 440);
            this.cantserv.Name = "cantserv";
            this.cantserv.Size = new System.Drawing.Size(45, 22);
            this.cantserv.TabIndex = 170;
            this.cantserv.Text = "1.0";
            this.cantserv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 445);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 169;
            this.label17.Text = "Clave:";
            // 
            // claveserv
            // 
            this.claveserv.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.claveserv.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.claveserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.claveserv.Location = new System.Drawing.Point(59, 440);
            this.claveserv.Name = "claveserv";
            this.claveserv.Size = new System.Drawing.Size(158, 22);
            this.claveserv.TabIndex = 168;
            this.claveserv.TextChanged += new System.EventHandler(this.claveserv_TextChanged);
            // 
            // addserv
            // 
            this.addserv.BackColor = System.Drawing.Color.Lime;
            this.addserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addserv.Location = new System.Drawing.Point(370, 440);
            this.addserv.Name = "addserv";
            this.addserv.Size = new System.Drawing.Size(23, 22);
            this.addserv.TabIndex = 171;
            this.addserv.Text = "+";
            this.addserv.UseVisualStyleBackColor = false;
            this.addserv.Click += new System.EventHandler(this.button10_Click);
            // 
            // precserv
            // 
            this.precserv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precserv.Location = new System.Drawing.Point(274, 440);
            this.precserv.Name = "precserv";
            this.precserv.Size = new System.Drawing.Size(90, 22);
            this.precserv.TabIndex = 172;
            this.precserv.Text = "1.0";
            this.precserv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // idser
            // 
            this.idser.Location = new System.Drawing.Point(4, 463);
            this.idser.Name = "idser";
            this.idser.Size = new System.Drawing.Size(12, 20);
            this.idser.TabIndex = 173;
            this.idser.Visible = false;
            // 
            // preci
            // 
            this.preci.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.preci.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.preci.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preci.Location = new System.Drawing.Point(118, 211);
            this.preci.Name = "preci";
            this.preci.Size = new System.Drawing.Size(158, 26);
            this.preci.TabIndex = 174;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 219);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 13);
            this.label10.TabIndex = 175;
            this.label10.Text = "Número de precinto:";
            // 
            // updt
            // 
            this.updt.BackColor = System.Drawing.Color.Lime;
            this.updt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updt.Location = new System.Drawing.Point(658, 26);
            this.updt.Name = "updt";
            this.updt.Size = new System.Drawing.Size(48, 22);
            this.updt.TabIndex = 179;
            this.updt.Text = "Actu.";
            this.updt.UseVisualStyleBackColor = false;
            this.updt.Click += new System.EventHandler(this.updt_Click);
            // 
            // cantedit
            // 
            this.cantedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cantedit.Location = new System.Drawing.Point(9, 27);
            this.cantedit.Name = "cantedit";
            this.cantedit.Size = new System.Drawing.Size(51, 20);
            this.cantedit.TabIndex = 178;
            this.cantedit.TextChanged += new System.EventHandler(this.cantedit_TextChanged);
            this.cantedit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantedit_KeyPress);
            // 
            // clavedit
            // 
            this.clavedit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.clavedit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.clavedit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clavedit.Location = new System.Drawing.Point(62, 27);
            this.clavedit.Name = "clavedit";
            this.clavedit.Size = new System.Drawing.Size(175, 20);
            this.clavedit.TabIndex = 176;
            this.clavedit.TextChanged += new System.EventHandler(this.clavedit_TextChanged);
            // 
            // palled
            // 
            this.palled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palled.Location = new System.Drawing.Point(619, 27);
            this.palled.Name = "palled";
            this.palled.Size = new System.Drawing.Size(39, 20);
            this.palled.TabIndex = 181;
            this.palled.TextChanged += new System.EventHandler(this.palled_TextChanged);
            this.palled.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.palled_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(457, 159);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(114, 13);
            this.label21.TabIndex = 272;
            this.label21.Text = "Pesos por contenedor:";
            // 
            // logcontainer
            // 
            this.logcontainer.Location = new System.Drawing.Point(454, 176);
            this.logcontainer.Multiline = true;
            this.logcontainer.Name = "logcontainer";
            this.logcontainer.ReadOnly = true;
            this.logcontainer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.logcontainer.Size = new System.Drawing.Size(270, 70);
            this.logcontainer.TabIndex = 271;
            this.logcontainer.TabStop = false;
            // 
            // kilose
            // 
            this.kilose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilose.Location = new System.Drawing.Point(555, 27);
            this.kilose.Name = "kilose";
            this.kilose.Size = new System.Drawing.Size(63, 20);
            this.kilose.TabIndex = 274;
            this.kilose.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kilose_KeyPress);
            // 
            // kgboxx
            // 
            this.kgboxx.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kgboxx.Location = new System.Drawing.Point(239, 27);
            this.kgboxx.Name = "kgboxx";
            this.kgboxx.ReadOnly = true;
            this.kgboxx.Size = new System.Drawing.Size(56, 20);
            this.kgboxx.TabIndex = 273;
            // 
            // palletkgs
            // 
            this.palletkgs.Location = new System.Drawing.Point(513, 27);
            this.palletkgs.Name = "palletkgs";
            this.palletkgs.ReadOnly = true;
            this.palletkgs.Size = new System.Drawing.Size(39, 20);
            this.palletkgs.TabIndex = 276;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(378, 30);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(133, 13);
            this.label20.TabIndex = 275;
            this.label20.Text = "Kgs. tarima con embalajes:";
            // 
            // neto
            // 
            this.neto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neto.Location = new System.Drawing.Point(770, 468);
            this.neto.Name = "neto";
            this.neto.ReadOnly = true;
            this.neto.Size = new System.Drawing.Size(132, 26);
            this.neto.TabIndex = 278;
            this.neto.Text = "0.00";
            this.neto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bruto
            // 
            this.bruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bruto.Location = new System.Drawing.Point(770, 496);
            this.bruto.Name = "bruto";
            this.bruto.ReadOnly = true;
            this.bruto.Size = new System.Drawing.Size(132, 26);
            this.bruto.TabIndex = 279;
            this.bruto.Text = "0.00";
            this.bruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(738, 503);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 282;
            this.label19.Text = "Bruto:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(738, 475);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 13);
            this.label18.TabIndex = 281;
            this.label18.Text = "Neto:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(738, 421);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(99, 16);
            this.label22.TabIndex = 280;
            this.label22.Text = "Total factura:";
            // 
            // totrefs
            // 
            this.totrefs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totrefs.Location = new System.Drawing.Point(739, 440);
            this.totrefs.Name = "totrefs";
            this.totrefs.ReadOnly = true;
            this.totrefs.Size = new System.Drawing.Size(163, 26);
            this.totrefs.TabIndex = 277;
            this.totrefs.Text = "0.00";
            this.totrefs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // addrows
            // 
            this.addrows.BackgroundImageTiled = true;
            this.addrows.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cantadded,
            this.claveadded,
            this.unidad,
            this.kgsbox,
            this.punit,
            this.totadded,
            this.containeradded,
            this.kgsrow,
            this.pallets});
            this.addrows.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrows.FullRowSelect = true;
            this.addrows.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.addrows.Location = new System.Drawing.Point(18, 338);
            this.addrows.MultiSelect = false;
            this.addrows.Name = "addrows";
            this.addrows.Size = new System.Drawing.Size(711, 99);
            this.addrows.TabIndex = 283;
            this.addrows.TabStop = false;
            this.addrows.UseCompatibleStateImageBehavior = false;
            this.addrows.View = System.Windows.Forms.View.Details;
            this.addrows.SelectedIndexChanged += new System.EventHandler(this.addrows_SelectedIndexChanged_1);
            this.addrows.Click += new System.EventHandler(this.addrows_Click_1);
            // 
            // cantadded
            // 
            this.cantadded.Text = "Cant.";
            this.cantadded.Width = 50;
            // 
            // claveadded
            // 
            this.claveadded.Text = "Clave";
            this.claveadded.Width = 113;
            // 
            // unidad
            // 
            this.unidad.Text = "Und.";
            this.unidad.Width = 65;
            // 
            // kgsbox
            // 
            this.kgsbox.Text = "Kilos Caja";
            // 
            // punit
            // 
            this.punit.Text = "P. Unitario";
            this.punit.Width = 78;
            // 
            // totadded
            // 
            this.totadded.Text = "Importe";
            this.totadded.Width = 112;
            // 
            // containeradded
            // 
            this.containeradded.Text = "Container";
            this.containeradded.Width = 79;
            // 
            // kgsrow
            // 
            this.kgsrow.Text = "Kgs Tot";
            // 
            // pallets
            // 
            this.pallets.Text = "Pallets";
            // 
            // states
            // 
            this.states.AutoSize = true;
            this.states.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.states.Location = new System.Drawing.Point(735, 10);
            this.states.Name = "states";
            this.states.Size = new System.Drawing.Size(0, 20);
            this.states.TabIndex = 284;
            this.states.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cue
            // 
            this.cue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cue.Location = new System.Drawing.Point(298, 27);
            this.cue.Name = "cue";
            this.cue.Size = new System.Drawing.Size(77, 20);
            this.cue.TabIndex = 285;
            this.cue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cue_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(60, 13);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 13);
            this.label24.TabIndex = 287;
            this.label24.Text = "Clave";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(8, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 13);
            this.label25.TabIndex = 288;
            this.label25.Text = "Cant m²:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(295, 13);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 13);
            this.label26.TabIndex = 289;
            this.label26.Text = "Precio";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(617, 14);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(36, 13);
            this.label27.TabIndex = 290;
            this.label27.Text = "Pallet.";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(236, 12);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 291;
            this.label28.Text = "Kgs x caja.";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(553, 13);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 292;
            this.label29.Text = "KgsTot";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.clavedit);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.cantedit);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.updt);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.palled);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.kgboxx);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.kilose);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.cue);
            this.groupBox3.Controls.Add(this.palletkgs);
            this.groupBox3.Controls.Add(this.delref);
            this.groupBox3.Location = new System.Drawing.Point(6, 279);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(729, 56);
            this.groupBox3.TabIndex = 293;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Editar partida";
            // 
            // editor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 591);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.states);
            this.Controls.Add(this.addrows);
            this.Controls.Add(this.neto);
            this.Controls.Add(this.bruto);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.totrefs);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.logcontainer);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.preci);
            this.Controls.Add(this.idser);
            this.Controls.Add(this.precserv);
            this.Controls.Add(this.addserv);
            this.Controls.Add(this.cantserv);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.claveserv);
            this.Controls.Add(this.delserv);
            this.Controls.Add(this.serves);
            this.Controls.Add(this.nucon);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.updtc);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.listpr);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.idadded);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.containsadd);
            this.Controls.Add(this.contains);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.containeradd);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cantadd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.cveadd);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "editor";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Editar Invoice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.editor_FormClosing);
            this.Load += new System.EventHandler(this.editor_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.editor_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox idadded;
        private System.Windows.Forms.Button delref;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox containsadd;
        private System.Windows.Forms.ListBox contains;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox containeradd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox cantadd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox cveadd;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox alba;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox oridest;
        private System.Windows.Forms.TextBox niff;
        private System.Windows.Forms.TextBox pais;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox edo;
        private System.Windows.Forms.TextBox mun;
        private System.Windows.Forms.TextBox cd;
        private System.Windows.Forms.TextBox col;
        private System.Windows.Forms.TextBox numi;
        private System.Windows.Forms.TextBox nume;
        private System.Windows.Forms.TextBox dirrec;
        private System.Windows.Forms.TextBox recnom;
        private System.Windows.Forms.TextBox nomemp;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox folio;
        private System.Windows.Forms.DateTimePicker fecha;
        private System.Windows.Forms.TextBox recep;
        private System.Windows.Forms.TextBox emit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox currency;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox obs2;
        private System.Windows.Forms.TextBox obs5;
        private System.Windows.Forms.TextBox obs1;
        private System.Windows.Forms.TextBox obs4;
        private System.Windows.Forms.TextBox obs3;
        private System.Windows.Forms.ComboBox listpr;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox foliaje;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox updtc;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox nucon;
        private System.Windows.Forms.ListView serves;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button delserv;
        private System.Windows.Forms.TextBox cantserv;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox claveserv;
        private System.Windows.Forms.Button addserv;
        private System.Windows.Forms.TextBox precserv;
        private System.Windows.Forms.TextBox idser;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.TextBox preci;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button updt;
        private System.Windows.Forms.TextBox cantedit;
        private System.Windows.Forms.TextBox clavedit;
        private System.Windows.Forms.TextBox palled;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox logcontainer;
        private System.Windows.Forms.TextBox kilose;
        private System.Windows.Forms.TextBox kgboxx;
        private System.Windows.Forms.TextBox palletkgs;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox neto;
        private System.Windows.Forms.TextBox bruto;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox totrefs;
        private System.Windows.Forms.ListView addrows;
        private System.Windows.Forms.ColumnHeader cantadded;
        private System.Windows.Forms.ColumnHeader claveadded;
        private System.Windows.Forms.ColumnHeader unidad;
        private System.Windows.Forms.ColumnHeader kgsbox;
        private System.Windows.Forms.ColumnHeader punit;
        private System.Windows.Forms.ColumnHeader totadded;
        private System.Windows.Forms.ColumnHeader containeradded;
        private System.Windows.Forms.ColumnHeader kgsrow;
        private System.Windows.Forms.ColumnHeader pallets;
        private System.Windows.Forms.Label states;
        private System.Windows.Forms.TextBox cue;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}